package com.books.librarymanagementsystem.service.impl;

import com.books.librarymanagementsystem.entity.Book;
import com.books.librarymanagementsystem.service.BookService;

public class BookServiceImpl implements BookService {

	@Override
	public String addBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

}

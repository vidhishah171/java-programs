package com.books.librarymanagementsystem.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.books.librarymanagementsystem.entity.Books;
import com.books.librarymanagementsystem.exception.BookNotFoundException;
import com.books.librarymanagementsystem.exception.BooksException;
import com.books.librarymanagementsystem.repo.BooksRepo;
import com.books.librarymanagementsystem.service.BooksService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookServiceImpl implements BooksService {

	@Autowired
	private BooksRepo booksRepo;

	@Override
	public String addBook(Books book) throws BooksException {
		if (Objects.nonNull(book)) {
			book = this.booksRepo.save(book);
			return "Book with title: " + book.getTitle() + " saved sucessfully with Id: " + book.getId() + ".";
		}
		throw new BooksException("Book object must not be null.");
	}

	@Override
	public Books getBook(Long id) throws BooksException {

		if (Objects.nonNull(id)) {

			Optional<Books> bookOptional = this.booksRepo.findById(id);
			if (bookOptional.isPresent()) {
				return bookOptional.get();
			} else {
				throw new BookNotFoundException("Unable to find book with Id: " + id + ".");
			}
		} else {
			throw new BooksException("Id must not be null for fetching books.");
		}
	}
	
	
	@Override
	public List<Books> getAllBooks(){

		return this.booksRepo.findAll();
	
	}

	@Override
	public Books updateBook(Long id, Books book) throws BooksException {

		try {
			Books oldBook = this.getBook(id);
//			Books.builder().title(book.getTitle()).author(book.getAuthor()).publicationYear(book.getPublicationYear()).build();
			oldBook.setAuthor(book.getAuthor());
			oldBook.setTitle(book.getTitle());
			oldBook.setPublicationYear(book.getPublicationYear());
			return this.booksRepo.save(oldBook);
		} catch (BooksException e) {
			throw new BooksException("Unable to update book with Id: " + id + "due to reason: " + e.getMessage());
		}
	}

	@Override
	public String deleteBook(Long id) throws BooksException {

		if (Objects.nonNull(id)) {
			if (this.booksRepo.existsById(id)) {
				this.booksRepo.deleteById(id);
				return "Book with Id: " + id + " deleted successfully.";
			} else {
				throw new BookNotFoundException("Unable to find book with Id: " + id + ".");
			}
		} else {
			throw new BooksException("Id must not be null for fetching books.");
		}

	}

}

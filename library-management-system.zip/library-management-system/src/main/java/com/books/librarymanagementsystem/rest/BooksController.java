package com.books.librarymanagementsystem.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.books.librarymanagementsystem.entity.Books;
import com.books.librarymanagementsystem.exception.BooksException;
import com.books.librarymanagementsystem.service.BooksService;

@RestController
@RequestMapping("/books")
public class BooksController {

	@Autowired
	private BooksService booksService;

	@PostMapping(value = "/add")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<String> addBook(@RequestBody Books bookObject) throws BooksException {
		return new ResponseEntity<String>(this.booksService.addBook(bookObject), HttpStatus.CREATED);
	}
	
	@GetMapping(value = "/get/{id}")
	public ResponseEntity<Books> fetchBook(@PathVariable Long id) throws BooksException {
		return new ResponseEntity<Books>(this.booksService.getBook(id), HttpStatus.OK);
	}
	
	@GetMapping(value = "/get")
	public ResponseEntity<List<Books>> fetchAllBooks() throws BooksException {
		return new ResponseEntity<List<Books>>(this.booksService.getAllBooks(), HttpStatus.OK);
	}
	
	@PutMapping(value = "/update/{id}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Books> updateBook(@PathVariable Long id, @RequestBody Books bookObject) throws BooksException {
		return new ResponseEntity<Books>(this.booksService.updateBook(id, bookObject), HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping(value = "delete/{id}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<String> deleteBook(@PathVariable Long id) throws BooksException {
		return new ResponseEntity<String>(this.booksService.deleteBook(id), HttpStatus.OK);
	}

}

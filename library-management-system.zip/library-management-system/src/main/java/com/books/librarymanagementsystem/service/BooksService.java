package com.books.librarymanagementsystem.service;

import java.util.List;

import com.books.librarymanagementsystem.entity.Books;
import com.books.librarymanagementsystem.exception.BooksException;

public interface BooksService {

	String addBook(Books book) throws BooksException;

	Books getBook(Long id) throws BooksException;

	Books updateBook(Long id, Books book) throws BooksException;

	String deleteBook(Long id) throws BooksException;

	List<Books> getAllBooks();
}

package com.books.librarymanagementsystem.entity;

import java.time.Year;


import org.hibernate.validator.constraints.NotBlank;
import com.books.librarymanagementsystem.entity.base.Auditable;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@SuppressWarnings("deprecation")
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "books")
public class Books extends Auditable {
	
	
	@NotBlank(message = "Book title must not be blank.")
	private String title;
	
	@NotBlank(message = "Book title must not be blank.")
	private String author;
	
	@NotNull
	private Year publicationYear;

}
